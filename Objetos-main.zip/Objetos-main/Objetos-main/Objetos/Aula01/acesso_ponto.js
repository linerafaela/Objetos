const objetoPessoa = {
    nome: 'Line',
    idade: 17,
    CPF: '11112223333',
    email: 'aline.rafaela.santos@escola.pr.gov.br'
}
//Acessando com os pontos
console.log(`O nome do cliente é ${objetoPessoa.nome} e sua idade ${objetoPessoa.idade}`)
