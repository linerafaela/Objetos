const pessoa = {
    nome: 'Roberta',
    profissao: 'Modelo'
};

console.log(pessoa.telefone)

pessoa.telefone = '43998429733'

console.log(pessoa.telefone);