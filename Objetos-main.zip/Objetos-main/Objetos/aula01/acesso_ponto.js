const objetoPessoa = {
    nome: 'Line',
    idade: 17,
    CPF: '11112223333',
    email: 'aline.rafaela.santos@escola.pr.gov.br'
}

console.log(objetoPessoa)